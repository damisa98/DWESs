<?php
/*
require_once("models/CategoriaModel.php");

class CategoriaController{

      
    public function ListarCategoria(){
       $categoria = new CategoriaModel();
       $todasCategorias = $categoria->TodasCategorias();
        require_once('views/usuario/Cabecera.php');      
    }
    
}
*/
    ?>