<div id="footer"  class="row">
     <div class="col">
        <p>FOOTER</p>
     </div>
 
</div>