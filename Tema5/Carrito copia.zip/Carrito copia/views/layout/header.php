       <div  class="row" >
            <div class="col" id="cabecera">
                <header>
                <p>VERO MODA</p>  
                </header>
                     
            </div>
       </div>
       <div  class="row" >
            <div class="col">
                <nav id="navegador" class="navbar navbar-inverse bg-secondary">
                    <ul class="navbar-nav">
                      
                        <li class="nav-item">
                            <a class="nav-link" href=".">Inicio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Sobre mi</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Contacto</a>
                        </li>                     
                    </ul>                   
                </nav>
            </div>
        </div> 
