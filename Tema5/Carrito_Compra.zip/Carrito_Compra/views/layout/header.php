<header>
    <img src="uploads/img/logo.png" alt="Logo">
    <h1>Mi carrito de la compra</h1>
</header>