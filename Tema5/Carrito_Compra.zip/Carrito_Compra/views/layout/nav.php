<ul>
    <li><a href="">Inicio</a></li>
</ul>