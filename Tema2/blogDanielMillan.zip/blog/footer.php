<footer>
    <h3>Redes sociales</h3>
    <ul class="nav">
        <li class="nav-item"><a href="http://www.facebook.com" class="nav-link"><img src="img/facebook.png" alt="Facebook" class="footerimg"></a></li>
        <li class="nav-item"><a href="http://www.instagram.com" class="nav-link"><img src="img/youtube.png" alt="insta" class="footerimg"></a></li>
        <li class="nav-item"><a href="http://www.twitter.com" class="nav-link"><img src="img/twitter.png" alt="twitter" class="footerimg"></a></li>
    </ul>
</footer>